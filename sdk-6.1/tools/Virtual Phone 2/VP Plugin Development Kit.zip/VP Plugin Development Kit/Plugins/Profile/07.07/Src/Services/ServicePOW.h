#pragma once
#include "Service.h"
#include "Cmd.h"
////////////////////////////////////////////////////////////////////////////

#ifdef DLLMANAGER_EXPORTS
	#define DLLMANAGER_API __declspec(dllexport)
#else
	#define DLLMANAGER_API __declspec(dllimport) 
#endif
////////////////////////////////////////////////////////////////////////////

class DLLMANAGER_API CServicePOW :
	public CService
{
public:
	CServicePOW(void);
	CServicePOW(CDllManager* iDllManager);
	virtual ~CServicePOW(void);
	Bool CFUN(CCmd* iCmd, Bool iSilentMode=0);
	Bool CBC(CCmd* iCmd, Bool iSilentMode=0);
	Bool _POW_(CCmd* iCmd, Bool iSilentMode=0);
	virtual Bool Dispatch(CCmd* iCmdP);
	virtual void OnConfigChange(int iConfigID);
	virtual void OnConfigChange(int iConfigID, int iConfigEvent);
	virtual Bool SetCFUN(CCmd* iCmdP, Bool iSilentMode);
};
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////