#pragma once

#ifndef SERVICESTY_H
#define SERVICESTY_H

#include "Service.h"
////////////////////////////////////////////////////////////////////////////////

#ifdef DLLMANAGER_EXPORTS
	#define DLLMANAGER_API __declspec(dllexport)
#else
	#define DLLMANAGER_API __declspec(dllimport) 
#endif
////////////////////////////////////////////////////////////////////////////////

class DLLMANAGER_API CServiceSTY : public CService
{

public:
	CServiceSTY() {};           // protected constructor used by dynamic creation
	CServiceSTY(CDllManager* iDllManager);
	virtual ~CServiceSTY();

public:
	// Commands Traitment
	virtual Bool kev(CCmd* iCmdP, Bool iSilentMode=0);	
	virtual Bool CPIN(CCmd* iCmdP, Bool iSilentMode=0);	
	virtual Bool CPWD(CCmd* iCmdP, Bool iSilentMode=0);
	// CServiceSTY message handlers
	virtual Bool Dispatch(CCmd* iCmdP);
	virtual void OnConfigChange(int iConfigID);		
	virtual void OnConfigChange(int iConfigID, int iConfigEvent);	
	virtual void InitPINState();
};
#endif
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

