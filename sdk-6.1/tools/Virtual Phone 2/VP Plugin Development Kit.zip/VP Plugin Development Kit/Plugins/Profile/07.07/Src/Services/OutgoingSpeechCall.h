#pragma once

#ifndef OUTGOINGCALL_H
#define OUTGOINGCALL_H

/////////////////////////////////////////////////////////////////////////////////////
#include "SpeechCall.h"
#include "ServiceSPC.h"
/////////////////////////////////////////////////////////////////////////////////////
class CServiceSPC;
////////////////////////////////////////////////////////////////////////////////
#ifdef DLLMANAGER_EXPORTS
	#define DLLMANAGER_API __declspec(dllexport)
#else
	#define DLLMANAGER_API __declspec(dllimport) 
#endif
/////////////////////////////////////////////////////////////////////////////////////
class DLLMANAGER_API COutgoingSpeechCall : public CSpeechCall
{
private:
	CServiceSPC* mServiceSPC;
public:
	COutgoingSpeechCall(void);
	COutgoingSpeechCall(CString iNumber, int iLineID, bool iCSSIenable, CConfigSPC* iCfgSPC, CServiceSPC* iSvcSPC);
	~COutgoingSpeechCall(void);	
public:
	virtual ESpcType GetType();
	virtual bool Connect();
	virtual bool Busy();
	virtual bool Error();
	virtual bool DialToAlert();	
};
#endif
