#pragma once
#include "ConfigSMS.h"
#include "resource.h"
#include "ConfigDlg.h"
#include "afxwin.h"
#include "afxcmn.h"
#include "ProfileDll.h"
// CConfigDataDlg dialog

class CConfigSMSDlg : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigSMSDlg)
private:
	virtual int		GetIconId()		{ return IDI_ICON_SMS; }; 
public:
	enum { IDD = IDD_DLGCFG_SMS_MAIN };
	CConfigSMSDlg(CConfigSMS* iCfgSMS): CConfigDlg(CConfigSMSDlg::IDD, theApp.m_hInstance, iCfgSMS){};   // standard constructor
	virtual ~CConfigSMSDlg(){};

protected:
	//virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

public:
	virtual BOOL OnInitDialog()		{ CDialog::OnInitDialog(); return TRUE; };
	virtual void UpdateDisplay()	{};
	virtual char* GetName()			{return "Sms";};
	virtual BOOL	Apply()			{ return TRUE; };


	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CConfigDATADlgSettings dialog
class CConfigSMSDlgSettings : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigSMSDlgSettings)

public:
	CConfigSMSDlgSettings(CConfigSMS* iCfgSMS): CConfigDlg(CConfigSMSDlgSettings::IDD, theApp.m_hInstance, iCfgSMS){};   // standard constructor
	virtual ~CConfigSMSDlgSettings() {};

// Dialog Data
	enum { IDD = IDD_DLGCFG_SMS_SETTINGS };
protected:
	virtual void	DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog();
	virtual void	UpdateDisplay();
	virtual char*	GetName()		{ return "Settings";};
	virtual BOOL	Apply();

	CEdit mCallCenterEdit;
	CEdit mMaxSmsIndex;
	CComboBox mMOSsmsServiceCombo;
	CComboBox mIndModeCombo;
	CComboBox mDeliverIndModeCombo;
	CComboBox mReportIndModeCombo;
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////