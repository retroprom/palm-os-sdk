#pragma once
/////////////////////////////////////////////////////////////////////////////
#include "afxwin.h"
#include "ProfileDll.h"
#include "ConfigDlg.h"
#include "ConfigCFG.h"
#include "Resource.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigCFGDlg dialog
class CConfigCFGDlg : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigCFGDlg)
private:
	virtual int		GetIconId()		{ return IDI_ICON_CFG; };
public:
	enum { IDD = IDD_DLGCFG_CFG_MAIN };
	CConfigCFGDlg(CConfigCFG* iCfgCFG) : CConfigDlg(CConfigCFGDlg::IDD, theApp.m_hInstance, iCfgCFG){};
	virtual ~CConfigCFGDlg() {};	
protected:
	virtual void DoDataExchange(CDataExchange* pDX)	{ CDialog::DoDataExchange(pDX); };
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog()	{ CDialog::OnInitDialog(); return TRUE; };
	virtual char*	GetName()		{ return "Configuration";};
	virtual void	UpdateDisplay()	{};
	virtual BOOL	Apply()			{ return TRUE; };
};
/////////////////////////////////////////////////////////////////////////////
// CConfigCFGDlg dialog
class CConfigCFGDlgSettings : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigCFGDlgSettings)
public:
	enum { IDD = IDD_DLGCFG_CFG_SETTINGS };
	CConfigCFGDlgSettings(CConfigCFG* iCfgCFG) : CConfigDlg(CConfigCFGDlgSettings::IDD, theApp.m_hInstance, iCfgCFG){};
	virtual ~CConfigCFGDlgSettings() {};	
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support	
	DECLARE_MESSAGE_MAP()
public:
	virtual void	UpdateDisplay();
	virtual char*	GetName()		{ return "Settings"; };
	virtual BOOL	OnInitDialog();
	virtual BOOL	Apply();
public:
	CEdit mEditBrand, mEditModel, mEditRevision, mEditNumber, mEditSerialNumber, mEditEmc;
};
/////////////////////////////////////////////////////////////////////////////
// CConfigCFGDlg dialog
class CConfigCFGDlgFacilities : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigCFGDlgFacilities)
public:
	enum { IDD = IDD_DLGCFG_CFG_FACILITIES };
	CConfigCFGDlgFacilities(CConfigCFG* iCfgCFG) : CConfigDlg(CConfigCFGDlgFacilities::IDD, theApp.m_hInstance, iCfgCFG){};
	virtual ~CConfigCFGDlgFacilities() {};	
protected:
	virtual void	DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	afx_msg void	OnCbnSelchangeComboFac();
	DECLARE_MESSAGE_MAP()
public:
	virtual void	UpdateDisplay();
	virtual char*	GetName()		{ return "Facilities"; };
	virtual BOOL	OnInitDialog();
	virtual BOOL	Apply();
	CString			GetComboKey(int iComboSel);
public:
	CEdit mEditFacPwd;
	CComboBox mComboFac;
	CButton mCheckVoice, mCheckData, mCheckFax, mCheckSms, mCheckDCS, mCheckDCA, mCheckDPA, mCheckDPADA;
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
