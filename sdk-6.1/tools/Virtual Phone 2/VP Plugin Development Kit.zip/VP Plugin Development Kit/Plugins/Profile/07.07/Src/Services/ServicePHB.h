#pragma once
#include "Service.h"
#include "PhoneBook.h"
////////////////////////////////////////////////////////////////////////////////
#ifdef DLLMANAGER_EXPORTS
	#define DLLMANAGER_API __declspec(dllexport)
#else
	#define DLLMANAGER_API __declspec(dllimport) 
#endif
////////////////////////////////////////////////////////////////////////////////
#define		kIndexNotEntered		65536
////////////////////////////////////////////////////////////////////////////////
class DLLMANAGER_API CServicePHB :	public CService
{
public:
	CServicePHB(void);
	CServicePHB(CDllManager* iDllManager);
	virtual ~CServicePHB(void);

	virtual Bool CPBS(CCmd* iCmdP, Bool iSilentMode=0);
	virtual Bool CPBW(CCmd* iCmdP, Bool iSilentMode=0);
	virtual Bool CPBR(CCmd* iCmdP, Bool iSilentMode=0);

	virtual int PrvWriteAllowed(int iIndex, CString iNumber, CString iText);
	virtual int PrvIsReadAllowed(int iIndex1, int iIndex2);
	virtual int PrvIsSelectAllowed(CString iID);
	virtual Bool Dispatch(CCmd* iCmdP);
	virtual void OnConfigChange(int iConfigID);
	virtual void AddPHBDlg(CString iStorage);
	virtual Err DeleteEntry(CPhoneBook* iPhb, int iIndex);
};
