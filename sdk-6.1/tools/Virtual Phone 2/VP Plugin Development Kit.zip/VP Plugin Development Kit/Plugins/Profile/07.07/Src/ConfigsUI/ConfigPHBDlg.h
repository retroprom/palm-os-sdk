#pragma once
/////////////////////////////////////////////////////////////////////////////
#include "resource.h"
#include "ProfileDll.h"
#include "ConfigPHB.h"
#include "afxwin.h"
/////////////////////////////////////////////////////////////////////////////
// CConfigPHBDlg dialog
class CConfigPHBDlg : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigPHBDlg)
private:
	virtual int		GetIconId()		{ return IDI_ICON_PHB; };
public:
	enum { IDD = IDD_DLGCFG_PHB_MAIN };
	CConfigPHBDlg(CConfigPHB* iCfgPHB) : CConfigDlg(CConfigPHBDlg::IDD, theApp.m_hInstance, iCfgPHB){};
	virtual ~CConfigPHBDlg() {};
protected:
	virtual void DoDataExchange(CDataExchange* pDX)	{ CDialog::DoDataExchange(pDX); };	
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog()	{ CDialog::OnInitDialog(); return TRUE; };
	virtual char*	GetName()		{ return "Phonebook";};
	virtual void	UpdateDisplay()	{};
	virtual BOOL	Apply()			{ return TRUE; };
};

/////////////////////////////////////////////////////////////////////////////
#define kFirstCheckID		3000
#define kMaxBtnCheck		50
/////////////////////////////////////////////////////////////////////////////
// CConfigPHBDlg dialog
class CConfigPHBDlgSettings : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigPHBDlgSettings)
public:
	enum { IDD = IDD_DLGCFG_PHB_SETTINGS };
	CConfigPHBDlgSettings(CConfigPHB* iCfgPHB);
	virtual ~CConfigPHBDlgSettings();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
	virtual void FillCombo();
	virtual void DrawCheckBox();
	afx_msg void OnChkClick(UINT iID);
	CObArray* mArrayChk;
public:
	virtual BOOL	OnInitDialog();
	virtual char*	GetName()		{ return "Settings";};
	virtual void	UpdateDisplay();;
	virtual BOOL	Apply();
	CEdit mEditMaxNameLength;	
	CComboBox mComboCurPHB;
};

