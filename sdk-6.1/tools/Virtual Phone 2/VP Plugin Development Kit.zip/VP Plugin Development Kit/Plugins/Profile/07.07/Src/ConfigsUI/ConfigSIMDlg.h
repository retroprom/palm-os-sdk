#pragma once
/////////////////////////////////////////////////////////////////////////////
#include "ProfileDll.h"
#include "ConfigDlg.h"
#include "ConfigSIM.h"
#include "afxwin.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigSIMDlg dialog
class CConfigSIMDlg : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigSIMDlg)
private:
	virtual int		GetIconId()		{ return IDI_ICON_SIM; };
public:
	enum { IDD = IDD_DLGCFG_SIM_MAIN };
	CConfigSIMDlg(CConfigSIM* iCfgSIM) : CConfigDlg(CConfigSIMDlg::IDD, theApp.m_hInstance, iCfgSIM){};
	virtual ~CConfigSIMDlg() {};	
protected:
	virtual void DoDataExchange(CDataExchange* pDX)	{ CDialog::DoDataExchange(pDX); };
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog()	{ CDialog::OnInitDialog(); return TRUE; };
	virtual char*	GetName()		{ return "SIM";};
	virtual void	UpdateDisplay()	{};
	virtual BOOL	Apply()			{ return TRUE; };
};

/////////////////////////////////////////////////////////////////////////////
// CConfigSIMDlg dialog
class CConfigSIMDlgSettings : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigSIMDlgSettings)
public:
	CConfigSIMDlgSettings(CConfigSIM* iCfgSIM) : CConfigDlg(CConfigSIMDlgSettings::IDD, theApp.m_hInstance, iCfgSIM){};
	virtual ~CConfigSIMDlgSettings() {};

// Dialog Data
	enum { IDD = IDD_DLGCFG_SIM_SETTINGS };

protected:
	virtual void	DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog();
	virtual void	UpdateDisplay();
	virtual char*	GetName()		{ return "Settings";};
	virtual BOOL	Apply();
public:
	CEdit			mEditIMSI, mEditVMNumber, mEditVMName;
	CButton			mCheckSIM;
};
