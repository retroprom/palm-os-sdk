// ProfileDll.h : main header file for the ProfileDll DLL
//

#include <afxtempl.h>

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif



#include "resource.h"		// main symbols

#ifdef DLLMANAGER_EXPORTS
	#define DLLMANAGER_API __declspec(dllexport)	
#else
	#define DLLMANAGER_API __declspec(dllimport)	
#endif


// CProfileDllApp
// See ProfileDll.cpp for the implementation of this class
//

class CProfileDllApp : public CWinApp
{
public:
	CProfileDllApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
extern CProfileDllApp theApp;