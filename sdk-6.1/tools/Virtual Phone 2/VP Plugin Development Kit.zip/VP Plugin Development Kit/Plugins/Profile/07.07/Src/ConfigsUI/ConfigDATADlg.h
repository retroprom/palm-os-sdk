#pragma once
#include "ConfigDATA.h"
#include "resource.h"
#include "ConfigDlg.h"
#include "afxwin.h"
#include "afxcmn.h"
#include "ProfileDll.h"
// CConfigDataDlg dialog

class CConfigDATADlg : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigDATADlg)
private:
	virtual int		GetIconId()		{ return IDI_ICON_DATA; }; 
public:
	enum { IDD = IDD_DLGCFG_DATA_MAIN };
	CConfigDATADlg(CConfigDATA* iCfgDATA): CConfigDlg(CConfigDATADlg::IDD, theApp.m_hInstance, iCfgDATA){};   // standard constructor
	virtual ~CConfigDATADlg(){};

protected:
	//virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

public:
	virtual BOOL OnInitDialog()		{ CDialog::OnInitDialog(); return TRUE; };
	virtual void UpdateDisplay()	{};
	virtual char* GetName()			{return "Data";};
	virtual BOOL	Apply()			{ return TRUE; };


	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CConfigDATADlgSettings dialog
class CConfigDATADlgSettings : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigDATADlgSettings)

public:
	CConfigDATADlgSettings(CConfigDATA* iCfgDATA): CConfigDlg(CConfigDATADlgSettings::IDD, theApp.m_hInstance, iCfgDATA){};   // standard constructor
	virtual ~CConfigDATADlgSettings() {};

// Dialog Data
	enum { IDD = IDD_DLGCFG_DATA_SETTINGS };
protected:
	virtual void	DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog();
	virtual void	UpdateDisplay();
	virtual char*	GetName()		{ return "Settings";};
	virtual BOOL	Apply();
public:
	CEdit mServAddEdit;
	CEdit mPortEdit;
	CComboBox mProtoCombo;
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////