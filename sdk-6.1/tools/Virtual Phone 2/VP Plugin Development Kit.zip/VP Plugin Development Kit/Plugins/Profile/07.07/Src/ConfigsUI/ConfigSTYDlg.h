#pragma once
/////////////////////////////////////////////////////////////////////////////
#include "resource.h"
#include "ProfileDll.h"
#include "ConfigDlg.h"
#include "ConfigSTY.h"
#include "afxwin.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigSTYDlg dialog
class CConfigSTYDlg : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigSTYDlg)
private:
	virtual int		GetIconId()		{ return IDI_ICON_STY; };
public:
	enum { IDD = IDD_DLGCFG_STY_MAIN };
	CConfigSTYDlg(CConfigSTY* iCfgSTY) : CConfigDlg(CConfigSTYDlg::IDD, theApp.m_hInstance, iCfgSTY){};
	virtual ~CConfigSTYDlg() {};	
protected:
	virtual void DoDataExchange(CDataExchange* pDX)	{ CDialog::DoDataExchange(pDX); };
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog()	{ CDialog::OnInitDialog(); return TRUE; };
	virtual char*	GetName()		{ return "Security";};
	virtual void	UpdateDisplay()	{};
	virtual BOOL	Apply()			{ return TRUE; };
};
/////////////////////////////////////////////////////////////////////////////
// CConfigSTYDlg dialog
class CConfigSTYDlgCodes : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigSTYDlgCodes)
public:
	CConfigSTYDlgCodes(CConfigSTY* iCfgSTY) : CConfigDlg(CConfigSTYDlgCodes::IDD, theApp.m_hInstance, iCfgSTY){};
	virtual ~CConfigSTYDlgCodes() {};
	// Dialog Data
	enum { IDD = IDD_DLGCFG_STY_CODES };
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()	
public:
	virtual void	UpdateDisplay();
	virtual char*	GetName()	{ return "Codes";};
	virtual BOOL	Apply();
	virtual BOOL	CheckCode(CString iCode, int iNbDigitMin, int iNbDigitMax, CString iErrorMsg);
	virtual BOOL	OnInitDialog();
	afx_msg void	OnBnClickedResetTries();
	CEdit mEditPin1, mEditPin2, mEditPuk1, mEditPuk2, mEditPin1Tries, mEditPin2Tries, mEditPuk1Tries, mEditPuk2Tries;
};
/////////////////////////////////////////////////////////////////////////////
// CConfigSTYDlgStatus dialog
class CConfigSTYDlgStatus : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigSTYDlgStatus)
public:
	CConfigSTYDlgStatus(CConfigSTY* iCfgSTY) : CConfigDlg(CConfigSTYDlgStatus::IDD, theApp.m_hInstance, iCfgSTY) {};
	virtual ~CConfigSTYDlgStatus() {};
	// Dialog Data
	enum { IDD = IDD_DLGCFG_STY_STATUS };
protected:
	CButton mCheckLockSIM;
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()		
public:
	virtual void	UpdateDisplay();
	virtual char*	GetName()	{ return "Status";};
	virtual BOOL	Apply();
	virtual BOOL	OnInitDialog();
	afx_msg void	OnBnClickedRdoReady();
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
