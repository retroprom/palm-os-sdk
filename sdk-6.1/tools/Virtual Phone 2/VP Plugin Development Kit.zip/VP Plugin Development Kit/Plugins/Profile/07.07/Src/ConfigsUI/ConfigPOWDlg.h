#pragma once
/*
#include "afxwin.h"
#include "afxcmn.h"
*/
#include "stdafx.h"

#include "ProfileDll.h"
#include "ConfigPOW.h"
#include "ConfigDlg.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigPOWDlg dialog
class CConfigPOWDlg : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigPOWDlg)
private:
	virtual int		GetIconId()		{ return IDI_ICON_POW; };
public:
	enum { IDD = IDD_DLGCFG_POW_MAIN };
	CConfigPOWDlg(CConfigPOW* iCfgPOW) : CConfigDlg(CConfigPOWDlg::IDD, theApp.m_hInstance, iCfgPOW){};
	virtual ~CConfigPOWDlg() {};	
protected:
	virtual void DoDataExchange(CDataExchange* pDX)	{ CDialog::DoDataExchange(pDX); };
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog()	{ CDialog::OnInitDialog(); return TRUE; };
	virtual char*	GetName()		{ return "Power";};
	virtual void	UpdateDisplay()	{};
	virtual BOOL	Apply()			{ return TRUE; };
};

/////////////////////////////////////////////////////////////////////////////
// CConfigPOWDlgSettings dialog
class CConfigPOWDlgSettings : public CConfigDlg
{
	DECLARE_DYNAMIC(CConfigPOWDlgSettings)

public:
	CConfigPOWDlgSettings(CConfigPOW* iCfgPOW) : CConfigDlg(CConfigPOWDlgSettings::IDD, theApp.m_hInstance, iCfgPOW){};
	virtual ~CConfigPOWDlgSettings() {};

// Dialog Data
	enum { IDD = IDD_DLGCFG_POW_SETTINGS };
protected:
	virtual void	DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog();
	virtual void	UpdateDisplay();
	virtual char*	GetName()		{ return "Settings";};
	virtual BOOL	Apply();
public:
	CComboBox		mBatStateCombo, mCFUNCombo;
	CSliderCtrl		mBatLevelSlide;
	afx_msg void	OnNMReleasedcapturePowBatlevelSlider(NMHDR *pNMHDR, LRESULT *pResult);
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////