#include "StdAfx.h"
#include "DllManagerCustomDll.h"
//////////////////////////////////////////////////////////////////////////////////////////
CDllManagerCustomDll::CDllManagerCustomDll(void)
{
}
//////////////////////////////////////////////////////////////////////////////////////////
CDllManagerCustomDll::~CDllManagerCustomDll(void) {}
//////////////////////////////////////////////////////////////////////////////////////////
void CDllManagerCustomDll::InitService() 
{	
	CConfig*				cfgSTY	= new CConfigSTY(this);
	CConfig*				cfgPOW	= new CConfigPOW(this);
	CConfig*				cfgNWK	= new CConfigNWK(this);
	CConfig*				cfgCFG	= new CConfigCFG(this);
	CConfig*				cfgSPC	= new CConfigSPCCustomDll(this);
	CConfig*				cfgGPRS	= new CConfigGPRS(this);
	CConfig*				cfgSIM	= new CConfigSIM(this);
	CConfig*				cfgDATA	= new CConfigDATA(this);
	CConfig*				cfgSMS	= new CConfigSMS(this);
	CConfig*				cfgPHB	= new CConfigPHB(this);

	AddConfig(CONFIG_STY,cfgSTY);
	AddConfig(CONFIG_POW,cfgPOW);
	AddConfig(CONFIG_NWK,cfgNWK);
	AddConfig(CONFIG_CFG,cfgCFG);
	AddConfig(CONFIG_SPC,cfgSPC);
	AddConfig(CONFIG_GPRS,cfgGPRS);
	AddConfig(CONFIG_SIM,cfgSIM);
	AddConfig(CONFIG_DATA,cfgDATA);
	AddConfig(CONFIG_SMS,cfgSMS);
	AddConfig(CONFIG_PHB,cfgPHB);

	CService*				svcSTY	= new CServiceSTY(this);									  
	CService*				svcSPC	= new CServiceSPCCustomDll(this);
	CService*				svcPOW	= new CServicePOW(this);
	CService*				svcNWK	= new CServiceNWK(this);
	CService*				svcCFG	= new CServiceCFG(this);
	CService*				svcGPRS	= new CServiceGPRS(this);
	CService*				svcSIM	= new CServiceSIM(this);
	CService*				svcDATA	= new CServiceDATA(this);
	CService*				svcSMS	= new CServiceSMS(this);
	CService*				svcPHB	= new CServicePHB(this);		
	
	AddService(SERVICE_STY,svcSTY);
	AddService(SERVICE_SPC,svcSPC);
	AddService(SERVICE_POW,svcPOW);
	AddService(SERVICE_NWK,svcNWK);
	AddService(SERVICE_CFG,svcCFG);
	AddService(SERVICE_GPRS,svcGPRS);
	AddService(SERVICE_SIM,svcSIM);
	AddService(SERVICE_DATA,svcDATA);
	AddService(SERVICE_SMS,svcSMS);
	AddService(SERVICE_PHB,svcPHB);	
}
//////////////////////////////////////////////////////////////////////////////////////////
CString CDllManagerCustomDll::GetIdentification() 
{
	 return "CustomDll";
}
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////