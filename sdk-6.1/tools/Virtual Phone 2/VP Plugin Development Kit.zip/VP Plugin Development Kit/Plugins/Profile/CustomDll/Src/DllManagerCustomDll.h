#pragma once
//////////////////////////////////////////////////////////////////////////////////////////
#include "0707DllManager.h"
#include "ServiceSIM.h"
#include "ServiceGPRS.h"
#include "ServiceNWK.h"
#include "ServicePOW.h"
#include "ServiceSPCCustomDll.h"
#include "ServiceCFG.h"
#include "ServiceSTY.h"
#include "ServiceDATA.h"
#include "ServicePHB.h"
#include "ServiceSMS.h"

#include "ConfigSIM.h"
#include "ConfigGPRS.h"
#include "ConfigNWK.h"
#include "ConfigPOW.h"
#include "ConfigSPCCustomDll.h"
#include "ConfigCFG.h"
#include "ConfigSTY.h"
#include "ConfigDATA.h"
#include "ConfigPHB.h"
#include "ConfigSMS.h"
//////////////////////////////////////////////////////////////////////////////////////////
#define DLLCUSTOM_API __declspec(dllexport)
//////////////////////////////////////////////////////////////////////////////////////////
class DLLCUSTOM_API CDllManagerCustomDll:public C0707DllManager 
{
public:
	 CDllManagerCustomDll(void);
	 virtual ~CDllManagerCustomDll(void);
	 virtual void InitService();
	 virtual CString GetIdentification();
};
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////