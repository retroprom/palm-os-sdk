#pragma once
//////////////////////////////////////////////////////////////////////////////////////////
#include "ConfigSPC.h"
////////////////////////////////////////////////////////////////////////////////////
#define		kCfgEventParamNChange	6100
#define		kParamNKey				"paramN"
#define		kParamNDefault			0
////////////////////////////////////////////////////////////////////////////////////
class CConfigSPCCustomDll : public CConfigSPC
{
private:
	int mParamN;
public:
	CConfigSPCCustomDll(void);
	CConfigSPCCustomDll(CDllManager* iDllManager);
	virtual ~CConfigSPCCustomDll(void);
	// Load Params From DBFIle
	virtual Bool Load();
	// Save Params In DBFile
	virtual Bool Save();
	// Param Accessor
	virtual void SetParamN(int iValue);
	virtual int	 GetParamN();
};
