/***********************************************************************
 *
 * Copyright (c) 2000 PalmSource, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************
 *
 * FILE:
 *	WinTextFile.h
 *
 * DESCRIPTION:
 *	
 *
 * AUTHOR:
 *	Octobrer  1, 2000	Created by Sami Hindawi(SHi)
 *	mmmm dd, yyyy	Now owned by .....
 *
 ***********************************************************************/
#ifndef		WINTEXTFILE_H
#define		WINTEXTFILE_H

#include	"VPIncs.h"
#include	"stdafx.h"
#include	"FileText.h"

/////////////////////////////////////////////////////////////////////////////
#ifdef COMMON_EXPORTS
	#define COMMON_API __declspec(dllexport)
#else
	#define COMMON_API __declspec(dllimport)
#endif
/////////////////////////////////////////////////////////////////////////////
#pragma warning (disable : 4251)
#pragma warning (disable : 4275)
/////////////////////////////////////////////////////////////////////////////
class COMMON_API CFileText 
{
private:
	Bool	mIsOpen;
	CFile	mFile;
protected:
	char*	mFileName;

public:
	CFileText(const char *iFullNameP);
	virtual ~CFileText();

	virtual Bool	Create();
	virtual Bool	Open();
	virtual UInt8	Delete(const char *iFullNameP);
	virtual Bool	Close();
	virtual Bool	Read();
	virtual Bool	Write(char *iBufP, UInt16 iCount);
	virtual void	GetUserDescription();
	const char *	GetFileName();
};

#endif


