#if !defined(AFX_PROPERTYLIST_H__74205380_1B56_11D4_BC48_00105AA2186F__INCLUDED_)
#define AFX_PROPERTYLIST_H__74205380_1B56_11D4_BC48_00105AA2186F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropertyList.h : header file
/////////////////////////////////////////////////////////////////////////////
#ifdef COMMON_EXPORTS
	#define COMMON_API __declspec(dllexport)
#else
	#define COMMON_API __declspec(dllimport)
#endif
/////////////////////////////////////////////////////////////////////////////
#pragma warning (disable : 4251)
#pragma warning (disable : 4275)
/////////////////////////////////////////////////////////////////////////////
#include "ShTarget.h"

#define PIT_COMBO		0  //PIT = property item type
#define PIT_EDIT		1
#define PIT_EDITWIDE	2
#define PIT_COLOR		3
#define PIT_FONT		4
#define PIT_FILE		5
#define PIT_BLOCKNAME	6
#define PIT_EMPTYLINE	7


#define IDC_PROPCMBBOX   712
#define IDC_PROPEDITBOX  713
#define IDC_PROPBTNCTRL  714

// Message ID to parent
#define ID_PROPERTY_CHANGED		11111
#define kPropertyChanged		0
#define kPropertyUpdated		1

#define ES_NUMBER_EXTENDED      0x4000L

/////////////////////////////////////////////////////////////////////////////
typedef	void (*UpdateFuncPtr)(int iMode, int iTag, void* ioParams);
/////////////////////////////////////////////////////////////////////////////
class COMMON_API CTagCtrl
{
public:
	int				tag;
	int				extNumber;
	void*			extTableP;
	int				ctrlType;
	int				value;
	CString			valueP;
	int				editCtrlMax;
	int				editCtrlType;
	BOOL			visible;
	UpdateFuncPtr	funcP;
public:
	CTagCtrl(int iTag, int iExtNumber, void* iExtTableP, int iCtrlType, int iValue, CString iValueP, int iEditCtrlMax, int iEditCtrlType, BOOL	iVisible, UpdateFuncPtr iFuncP)
		{
		tag = iTag;					extNumber = iExtNumber;
		extTableP = iExtTableP;		ctrlType = iCtrlType;
		value = iValue;				valueP = iValueP;
		editCtrlMax = iEditCtrlMax;	editCtrlType = iEditCtrlType;
		visible = iVisible;			funcP = iFuncP;
		};
};
/////////////////////////////////////////////////////////////////////////////
//CPropertyList Items
class COMMON_API CPropertyItem
{
// Attributes
public:
	CString m_propName;
	CString m_curValue;
	int		m_curIndex;
	int		m_nItemType;
	CString m_cmbItems;
	Bool	m_Visible;
	Bool	m_Title;
	int		m_EditTextLimit;
	DWORD	m_EditTextType;

public:
	CPropertyItem(){};
	CPropertyItem(CString propName, CString curValue, int nItemType, CString cmbItems, Bool nVisible, Bool nTitle, int nTextLimit, DWORD nTextType)
		{
		m_propName	= propName;
		m_curValue	= curValue;
		m_cmbItems	= cmbItems;
		m_nItemType = nItemType;
		m_Visible	= nVisible;
		m_Title		= nTitle;
		m_curIndex	= -1;
		m_EditTextLimit = nTextLimit;
		m_EditTextType = nTextType;
		};

	~CPropertyItem(){};
};

/////////////////////////////////////////////////////////////////////////////
// CPropertyList window

class COMMON_API CPropertyList : public CListBox
{
// Construction
public:
	CPropertyList();

// Attributes
public:

// Operations
public:
	int AddItem(CString txt);
	int AddPropItem(CPropertyItem* pItem);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertyList)
	public:
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPropertyList();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPropertyList)
	afx_msg int		OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void	OnDestroy();
	afx_msg void	OnSelchange(); 
	afx_msg void	OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void	OnKillFocus(CWnd* pNewWnd);
	afx_msg void	OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void	OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL	OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	//afx_msg void	OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	afx_msg void OnKillfocusCmbBox();
	afx_msg void OnSelchangeCmbBox();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar *pScrollBar);
	afx_msg void OnKillfocusEditBox();
	afx_msg void OnChangeEditBox();
//	afx_msg void OnKeyChangeEditBox(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButton();

	DECLARE_MESSAGE_MAP()

	void InvertLine(CDC* pDC,CPoint ptFrom,CPoint ptTo);
	void DisplayButton(CRect region);

	CEdit		*m_editBoxP;
	CEdit		*m_editWideBoxP;
	CComboBox	m_cmbBox;
	CButton		m_btnCtrl;
	CFont		m_SSerif8Font;
	
	int		m_curSel,m_prevSel;
	int		m_nDivider;
	int		m_nDivTop;
	int		m_nDivBtm;
	int		m_nOldDivX;
	int		m_nLastBox;
	BOOL	m_bTracking;
	BOOL	m_bDivIsSet;
	HCURSOR m_hCursorArrow;
	HCURSOR m_hCursorSize;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYLIST_H__74205380_1B56_11D4_BC48_00105AA2186F__INCLUDED_)
