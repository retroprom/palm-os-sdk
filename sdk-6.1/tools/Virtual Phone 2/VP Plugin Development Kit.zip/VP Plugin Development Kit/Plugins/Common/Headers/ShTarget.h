/***********************************************************************
 *
 * Copyright (c) 2000 PalmSource, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************
 *
 * FILE:
 *	ShTarget.h
 *
 * DESCRIPTION:
 *	
 *
 * AUTHOR:
 *	November 11, 2000	Created by Frank Lefebvre (FLe)
 *	mmmm dd, yyyy	Now owned by .....
 *
 ***********************************************************************/

#ifndef SHTARGET_H
#define SHTARGET_H

#ifdef WIN32
#	define OS_WIN32				1
#	define OS_MAC				0
#else
#	if TARGET_OS_MAC
#		define OS_WIN32			0
#		define OS_MAC			1
#	else
#		error Unknown target
#	endif
#endif

#define errNone					0

#define false					0
#define true					1

#if OS_WIN32
	typedef unsigned char	UInt8;
	typedef	unsigned short	UInt16;
	typedef unsigned long	UInt32;
	typedef	UInt32			MessageT;
#endif

typedef	signed char		Int8;
typedef signed short	Int16;
typedef signed long		Int32;

typedef unsigned char	uchar;

typedef	unsigned long	Err;
typedef int 			Bool;

#endif
