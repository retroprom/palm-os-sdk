#pragma once
/////////////////////////////////////////////////////////////////////////////
#ifdef COMMON_EXPORTS
	#define COMMON_API __declspec(dllexport)
#else
	#define COMMON_API __declspec(dllimport)
#endif
/////////////////////////////////////////////////////////////////////////////
class COMMON_API CRegStorage
{
private:
	HKEY mRegKey;
	DWORD mRegKeyStatus;
	CString mKeyName;
public:
	CRegStorage(CString iKeyName);
	virtual ~CRegStorage(void);
	LONG		Init();
	LONG		WriteInt(CString iParamName, int iData);
	LONG		WriteString(CString iParamName, CString iData);
	LONG		ReadInt(CString iParamName, int* oValue, int DefaultValue);
	LONG		ReadString(CString iParamName, CString* oValue, CString DefaultValue);
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////