#pragma once

/////////////////////////////////////////////////////////////////////////////
#ifdef COMMON_EXPORTS
	#define COMMON_API __declspec(dllexport)
#else
	#define COMMON_API __declspec(dllimport)
#endif
/////////////////////////////////////////////////////////////////////////////

class COMMON_API CListener
{
public:
	CListener(void);
	virtual ~CListener(void);
	virtual void OnConfigChange(int configID)=0;
	virtual void OnConfigChange(int configID, int iConfigEvent) {};
};
