#pragma once
#include "TreeCtrlEx.h"
/////////////////////////////////////////////////////////////////////////////
#ifdef COMMON_EXPORTS
	#define COMMON_API __declspec(dllexport)
#else
	#define COMMON_API __declspec(dllimport)
#endif
/////////////////////////////////////////////////////////////////////////////
class COMMON_API CTreeCtrlExCheckBoxes :
	public CTreeCtrlEx
{
	DECLARE_DYNCREATE(CTreeCtrlExCheckBoxes)
public:	
	CTreeCtrlExCheckBoxes(void);
	virtual ~CTreeCtrlExCheckBoxes(void);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void SetCoherentState(HTREEITEM iItem);
	virtual void CreateTree(CList<CTreeParam*,CTreeParam*>* iParamsListP);
	void	UncheckChildren(HTREEITEM iItem);	
protected:	
	HTREEITEM	mLastChecked;
	DECLARE_MESSAGE_MAP()	
};
