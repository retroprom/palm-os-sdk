#pragma once

/////////////////////////////////////////////////////////////////////////////
#ifdef COMMON_EXPORTS
	#define COMMON_API __declspec(dllexport)
#else
	#define COMMON_API __declspec(dllimport)
#endif
/////////////////////////////////////////////////////////////////////////////
#include <afxcoll.h>

class COMMON_API CBroadcaster
{
private:
	CObList mListener;
	BOOL	mMute;
public:
	CBroadcaster(void);
	virtual ~CBroadcaster(void);
	virtual void AddListener(CObject* iListener);
	virtual void RemoveListener(CObject* iListener);
	virtual void Broadcast(int configID);
	virtual void Broadcast(int configID, int iConfigEvent);
	virtual void Mute(BOOL iState) {mMute=iState;};
	virtual BOOL IsMute() {return mMute;};
};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
