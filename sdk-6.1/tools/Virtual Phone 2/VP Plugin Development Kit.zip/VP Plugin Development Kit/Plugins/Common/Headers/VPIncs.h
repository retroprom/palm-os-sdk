/***********************************************************************
 *
 * Copyright (c) 2000 PalmSource, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************
 *
 * FILE:
 *	VPIncs.h
 *
 * DESCRIPTION:
 *	
 *
 * AUTHOR:
 *	June  1, 2000	Created by Sami Hindawi(SHi)
 *	mmmm dd, yyyy	Now owned by .....
 *
 ***********************************************************************/

#ifndef VPINCS_H
#define VPINCS_H

#include "ShTarget.h"
#include "CATMessage.h"
/////////////////////////////////////////////////////////////////////////////
#define resetPtrT(ptr)				if(ptr!=NULL){delete [] ptr; ptr=NULL;}
#define resetPtr(ptr)				if(ptr!=NULL){delete ptr; ptr=NULL;}
#define MAX_COM_MOD					20

// VP Specific events
#define WM_PRINT_MSG_ON_VP			WM_APP+1
#define WM_SEND_AT_REPLY			WM_APP+2
#define WM_VP_COM_MUX				WM_APP+3
#define WM_COM_VP_MUX				WM_APP+4
#define WM_COM_VP_OPEN				WM_APP+5
#define WM_COM_VP_CLOSE				WM_APP+6
#define WM_DLG_PARAM_CHANGED		WM_APP+7
#define WM_VP_SVC_VIB				WM_APP+8
#define WM_OUT_AT_LOG				WM_APP+9
#define WM_IN_AT_LOG				WM_APP+10
#define	WM_REFRESH_CFG_TREE			WM_APP+11
#define WM_NOTIF_ECHO				WM_APP+12
#define WM_APPEND_MAIN_LOG			WM_APP+13
#define WM_GETLOWLINK				WM_APP+14

// UI update codes
#define	kUpdateItemChanged			0
#define	kUpdateItemRenamed			1
#define	kUpdateItemReload			2
#define	kUpdateItemJump				3

const UInt16 kMaxStringLength = 1024;

/////////////////////////////////////////////////////////////////////////////
// Dlg Message Param Class 
class CDlgMsgParam
{
public:
	int			mAction;
	void*		mParamP;
public:
	CDlgMsgParam()	{ mAction = -1; mParamP = NULL; };
	~CDlgMsgParam()	{ };
};
/////////////////////////////////////////////////////////////////////////////
#endif
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
