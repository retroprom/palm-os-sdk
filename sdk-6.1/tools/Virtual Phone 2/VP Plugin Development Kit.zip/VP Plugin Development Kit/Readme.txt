This kit includes files required to build a StandardGSM based custom plugin for VirtualPhone v2.0

- Plugins\Profile\CustomDll\CustomDll.sln is a simple sample (MS�VS2003 solution) that extents the Standard 07.07/07.05 GSM plugin
 and defines a sample AT command +CSTM