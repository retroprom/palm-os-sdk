[Disclaimer]

This program is subject to copyright protection in accordance with the
applicable law and is also subject to the Developer Download Software
License Agreement, ("License Agreement") agreed to by the licensee prior to
download and receipt of this program.  It must only be used for the purpose
of developing software that is compatible with the CLI� handheld computer.
It must not, except as permitted in the License Agreement, by any means or
in any form be reproduced, distributed or lent.  Moreover, no part of the
program may be used, viewed, printed, disassembled or otherwise interfered
with in any form, except where allowed by the License Agreement, without the
express written consent of the copyright holder.

THIS PROGRAM IS FURTHER PROVIDED "AS IS" WITH NO WARRANTY OF ANY KIND AND
THE COPYRIGHT HOLDER HEREBY DISCLAIMS ALL WARRANTIES, EXPRESS AND IMPLIED AS
TO THE PROGRAM.

Copyright (c) 2002 Sony Electronics Inc.
Some portions copyright (c) 1999 Palm Computing, Inc. or its subsidiaries.
All Rights Reserved.


[Overview]

HRLibSample is a sample application to demonstrate the difference of the 
Sony High resoultion Library between pre-PalmOS 5 and PalmOS 5.

The major features included in the sample are

* How to distinguish the HRLib version
* How to draw messages properly in HR fonts when using old HRLib vs. the new one


[Build Environment]

* Metrowerks Code Warrior R7
* Palm OS SDK 5.0
* Sony SDK 5.0


[Revision History]

10/31/2002 1.0
	Initial Version